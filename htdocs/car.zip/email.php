<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
	require_once "Mail.php";
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

	$host = "host.pcsaved.com";
	$username = "email@pcsaved.com";
	$password = "Bluffton1!";
	$headers = array ('From' => $email,
	'To' => "majditahaps@gmail.com",
	'Subject' => $name);
	$smtp = Mail::factory('smtp',
	array ('host' => $host,
		'auth' => true,
		'username' => $username,
		'password' => $password));
//var_dump($smtp);
	$mail = $smtp->send("majditahaps@gmail.com", $headers, $message);

	if (PEAR::isError($mail)) {
	echo("<p>" . $mail->getMessage() . "</p>");
	} else {
	echo("Message successfully sent!");
	}
?>